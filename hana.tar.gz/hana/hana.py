#!/usr/bin/env python
import libpyprotect
from _hana import run

if __name__ == '__main__':
    run()

