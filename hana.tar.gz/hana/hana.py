#!/usr/bin/env python
import libpyprotect
from _hana import chay_tool

if __name__ == '__main__':
    chay_tool()

